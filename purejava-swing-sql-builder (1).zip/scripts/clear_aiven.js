import pg from 'pg';

const { Client } = pg;

async function clearAivenData() {
  console.log("Connecting to Aiven Cloud PostgreSQL to clear rows...");
  const client = new Client({
    host: "pg-24c49dac-gowthamgowri73-1585.h.aivencloud.com",
    port: 28072,
    database: "defaultdb",
    user: "avnadmin",
    password: "AVNS_nVugcLn4ave9v5rR8kF",
    ssl: { rejectUnauthorized: false }
  });

  try {
    await client.connect();
    console.log("Connected to Aiven PostgreSQL.");

    // Truncate tables to remove default seed rows
    await client.query("TRUNCATE TABLE expenses, ventures CASCADE;");
    console.log("[OK] Truncated tables: expenses, ventures.");

    // Check counts
    const vRes = await client.query("SELECT count(*) FROM ventures;");
    const eRes = await client.query("SELECT count(*) FROM expenses;");
    console.log(`Remaining ventures count in Aiven: ${vRes.rows[0].count}`);
    console.log(`Remaining expenses count in Aiven: ${eRes.rows[0].count}`);

    // Reset sequences
    await client.query("ALTER SEQUENCE ventures_id_seq RESTART WITH 1;");
    await client.query("ALTER SEQUENCE expenses_id_seq RESTART WITH 1;");
    console.log("[OK] Sequences reset to 1.");

  } catch (err) {
    console.error("Error clearing Aiven database:", err);
    process.exit(1);
  } finally {
    await client.end();
    console.log("Aiven Cloud database cleaned.");
  }
}

clearAivenData();
