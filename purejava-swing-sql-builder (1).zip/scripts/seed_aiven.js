import pg from 'pg';
import fs from 'fs';
import path from 'path';

const { Client } = pg;

async function runSeed() {
  console.log("Connecting to Aiven Cloud PostgreSQL...");
  const client = new Client({
    host: "pg-24c49dac-gowthamgowri73-1585.h.aivencloud.com",
    port: 28072,
    database: "defaultdb",
    user: "avnadmin",
    password: "AVNS_nVugcLn4ave9v5rR8kF",
    ssl: {
      rejectUnauthorized: false
    }
  });

  try {
    await client.connect();
    console.log("[OK] Successfully connected to Aiven PostgreSQL cloud instance!");

    const sqlScript = fs.readFileSync(path.resolve('./schema_postgres.sql'), 'utf-8');
    console.log("Executing schema_postgres.sql statements...");

    await client.query(sqlScript);
    console.log("[OK] Schema created and initial seed data inserted successfully!\n");

    // Verification queries
    console.log("--- TABLE: users ---");
    const usersRes = await client.query("SELECT id, username, email, full_name FROM users;");
    console.table(usersRes.rows);

    console.log("--- TABLE: ventures ---");
    const venturesRes = await client.query("SELECT id, startup_name, decision_tier, overall_score, post_money_val, runway_months FROM ventures;");
    console.table(venturesRes.rows);

    console.log("--- TABLE: expenses ---");
    const expensesRes = await client.query("SELECT id, venture_id, category, description, amount, is_revenue, month_year FROM expenses;");
    console.table(expensesRes.rows);

    console.log("All tables populated with data in Aiven PostgreSQL defaultdb.");

  } catch (err) {
    console.error("Database seed error:", err);
    process.exit(1);
  } finally {
    await client.end();
    console.log("Connection closed.");
  }
}

runSeed();
